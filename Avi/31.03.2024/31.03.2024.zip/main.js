// Function to check if the input is a valid hexadecimal color format
function isValidHexColor(color) {
  const regex = /^#([0-9A-F]{3}){1,2}$/i;
  return regex.test(color);
}

// Function that is called when the color is input or the button is clicked
function changeBackgroundColor() {
  // Get the value from the color input field
  var colorInput = document.getElementById("colorInput").value;
  // Get the value from the color picker
  var colorWindow = document.getElementById("colorWindow").value;

  // Check if the input color is valid
  if (isValidHexColor(colorInput)) {
    // If the color is valid, change the background color of the page to the input color
    document.body.style.backgroundColor = colorInput;
  } else if (isValidHexColor(colorWindow)) {
    // If the color picker's color is valid, change the background color of the page to the picker's color
    document.body.style.backgroundColor = colorWindow;
  } else {
    // If the color is not valid, show an error message
    alert("Please enter color is not in hex format (e.g., #FFFFFF)");
  }
}

// Add an event listener for the button click after the page content is fully loaded
document.addEventListener("DOMContentLoaded", function () {
  // Listen for color changes in the color picker in real-time
  document
    .getElementById("colorWindow")
    .addEventListener("input", changeBackgroundColor);
  // Listen for clicks on the change color button
  document
    .getElementById("changeColorButton")
    .addEventListener("click", changeBackgroundColor);
});

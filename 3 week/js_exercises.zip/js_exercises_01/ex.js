let myString = "Hello, world!";
let myNumber = 42;
let p2 = {
	name: "Robert",
	age: 25,
	city: "Jerusalem"}
let myHomeWork = true;
let myTime = null;
let myUndefined;
let myUniqueSymbol = Symbol('my symbol');


console.log(typeof myString);
console.log(myNumber);
console.log(p2);
console.log(myHomeWork);
console.log(myTime);
console.log(myUndefined);
console.log(myUniqueSymbol);
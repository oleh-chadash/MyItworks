function myCircleArea (radius){
    const area = Math.PI * Math.pow(radius, 2);
    console.log("The area is: ", area);
    console.log("Rounded to two decimal places: ", area.toFixed(2));
}
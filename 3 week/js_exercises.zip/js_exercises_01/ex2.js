function countryInfo(country, population, capitalCity) {
    return `${country} has ${population} million people and its capital city is ${capitalCity}`;
}

const country1 = countryInfo('Spain', 47, 'Madrid');
const country2 = countryInfo('France', 67, 'Paris');
const country3 = countryInfo('Italy', 60, 'Rome');

console.log(country1);
console.log(country2);
console.log(country3);